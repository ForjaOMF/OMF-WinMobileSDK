using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Localizame
{
    public partial class frmMain : Form
    {
        private LocalizameApi.Localizame _loc = null;

        public frmMain()
        {
            InitializeComponent();
            
            mnuLogin.Enabled = true;
            mnuLocate.Enabled = false;
            mnuAuthorize.Enabled = false;
            mnuUnautorize.Enabled = false;
            mnuLogout.Enabled = false;

            txtLogin.Text = RegManager.Read("MovistarTest/Common", "login", "");
            txtPwd.Text = RegManager.Read("MovistarTest/Localizame", "pwd", "");
        }

        private void mnuQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mnuLogin_Click(object sender, EventArgs e)
        {
            _loc = new LocalizameApi.Localizame();
            try
            {
                if (_loc.Login(txtLogin.Text, txtPwd.Text))
                {
                    RegManager.Write("MovistarTest/Common", "login", txtLogin.Text);
                    RegManager.Write("MovistarTest/Localizame", "pwd", txtPwd.Text );

                    mnuLogin.Enabled = true;
                    mnuLocate.Enabled = true;
                    mnuAuthorize.Enabled = true;
                    mnuUnautorize.Enabled = true;
                    mnuLogout.Enabled = true;

                    MessageBox.Show("Login Ok","Login", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
                }
                else
                    MessageBox.Show("Unable to login: " + _loc.GetLastError(), "Login", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Internal Error: " + ex.Message, "Login", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        private void mnuLocate_Click(object sender, EventArgs e)
        {
            try
            {
                string location = _loc.Locate(txtPhone.Text);
                if (location != null && location.Length > 0)
                {
                    MessageBox.Show("Location: " + location,  "Location", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
                }
                else
                    MessageBox.Show("Location Error: " + _loc.GetLastError(), "Location", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Internal Error: " + ex.Message, "Locate", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        private void mnuAuthorize_Click(object sender, EventArgs e)
        {
            try
            {
                if (_loc.Authorize(txtPhone.Text))
                {
                    MessageBox.Show("Authorization succeded", "Authorize", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
                }
                else
                    MessageBox.Show("Authorization Error: " + _loc.GetLastError(), "Authorize", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Internal Error: " + ex.Message, "Authorize", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        private void mnuUnautorize_Click(object sender, EventArgs e)
        {
            try
            {
                if (_loc.Unauthorize(txtPhone.Text))
                {
                    MessageBox.Show("Unauthorize succeded", "Unauthorize", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
                }
                else
                    MessageBox.Show("Unauthorize Error: " + _loc.GetLastError(), "Unauthorize", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Internal Error: " + ex.Message, "Unauthorize", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        private void mnuLogout_Click(object sender, EventArgs e)
        {
            try
            {
                if (_loc.Logout())
                {
                    mnuLogin.Enabled = true;
                    mnuLocate.Enabled = false;
                    mnuAuthorize.Enabled = false;
                    mnuUnautorize.Enabled = false;
                    mnuLogout.Enabled = false;

                    MessageBox.Show("Logout succeded", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
                }
                else
                    MessageBox.Show("Logout Error: " + _loc.GetLastError(), "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Internal Error: " + ex.Message, "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        
    }
}