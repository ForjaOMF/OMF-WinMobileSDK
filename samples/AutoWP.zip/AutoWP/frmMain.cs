using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MovistarAutoWP
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
            
            //Read default values from registry
            txtLogin.Text = RegManager.Read("MovistarTest/Common", "login", "");
            txtPwd.Text = RegManager.Read("MovistarTest/Common", "pwd", "");
            txtUrl.Text = RegManager.Read("MovistarTest/AutoWP", "url", "");
            txtText.Text = RegManager.Read("MovistarTest/AutoWP", "text", "");
        }

        private void mnuQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mnuSend_Click_1(object sender, EventArgs e)
        {
            mnuSend.Enabled = false;
            Cursor.Current = Cursors.WaitCursor;
            AutoWPApi.AutoWP autoWP = new AutoWPApi.AutoWP();
            try
            {
                string ret = autoWP.SendAutoWP(txtLogin.Text, txtPwd.Text, txtUrl.Text, txtText.Text);
                if (ret != null)
                {
                    if (ret == "0")
                    {
                        MessageBox.Show("AutoWP Sent Successfully", "AutoWP Send", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);

                        // Save default values to windows registry
                        RegManager.Write("MovistarTest/Common", "login", txtLogin.Text);
                        RegManager.Write("MovistarTest/Common", "pwd", txtPwd.Text);
                        RegManager.Write("MovistarTest/AutoWP", "url", txtUrl.Text);
                        RegManager.Write("MovistarTest/AutoWP", "text", txtText.Text);
                    }
                    else
                        MessageBox.Show("Server Response: " + autoWP.GetLastError(), "AutoWP Send", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
                else
                    MessageBox.Show("Unable to send AutoWP: " + autoWP.GetLastError(), "AutoWP Send", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Internal Error: " + ex.Message, "AutoWP Send", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            autoWP = null;
            mnuSend.Enabled = true;
            Cursor.Current = Cursors.Default;
        }

        

    }
}