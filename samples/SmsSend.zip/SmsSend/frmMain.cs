using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MovistarSmsSend
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();

            //Read default values from registry
            txtLogin.Text = RegManager.Read("MovistarTest/Common", "login", "");
            txtPwd.Text = RegManager.Read("MovistarTest/Common", "pwd", "");
            txtDestination.Text = RegManager.Read("MovistarTest/SmsSend", "destination", "");
            txtData.Text = RegManager.Read("MovistarTest/SmsSend", "body","");
        }

        private void mnuQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mnuSend_Click(object sender, EventArgs e)
        {
            mnuSend.Enabled = false;
            Cursor.Current = Cursors.WaitCursor;
            SmsSendApi.SMSSender smsSender = new SmsSendApi.SMSSender();
            try
            {
                string ret = smsSender.SendMessage(txtLogin.Text, txtPwd.Text,txtDestination.Text, txtData.Text);
                if (ret!=null)
                {
                    if (ret.ToLower() == "ok")
                    {
                        MessageBox.Show("SMS Sent Successfully", "SMS Send", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
                        // Save default values to windows registry
                        RegManager.Write("MovistarTest/Common", "login", txtLogin.Text);
                        RegManager.Write("MovistarTest/Common", "pwd", txtPwd.Text);
                        RegManager.Write("MovistarTest/SmsSend", "destination", txtDestination.Text);
                        RegManager.Write("MovistarTest/SmsSend", "body", txtData.Text);
                    }
                    else
                        MessageBox.Show("Server Response: " + ret, "SMS Send", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                }
                else
                    MessageBox.Show("Unable to send SMS: " + smsSender.GetLastError(), "SMS Send", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Internal Error: " + ex.Message, "SMS Send", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            smsSender = null;
            mnuSend.Enabled = true;
            Cursor.Current = Cursors.Default;
        }
    }
}