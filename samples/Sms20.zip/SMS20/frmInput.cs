using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SMS20
{
    public partial class frmInput : Form
    {
        public string ReturnValue = null;

        public frmInput(string legend,string defaultValue)
        {
            InitializeComponent();
            this.Text = "Input Value";
            lbLegend.Text = legend;
            txtValue.Text = defaultValue;
        }

        private void mnuOk_Click(object sender, EventArgs e)
        {
            this.ReturnValue = txtValue.Text;
            this.Close();
        }

        private void mnuCancel_Click(object sender, EventArgs e)
        {
            this.ReturnValue = null;
            this.Close();
        }
    }
}