using System;
using Microsoft.Win32;
using System.Text;
using System.Collections;

namespace SMS20
{
    /// <summary>
    /// Helper class to deal width windows registry
    /// </summary>
    public static class RegManager
    {
        public static string Read(string path, string name, string defaultValue)
        {
            RegistryKey key = null;
            try
            {
                key = Registry.LocalMachine.OpenSubKey(path.Replace("/", "\\"), false);
            }
            catch { }
            if (key == null)
                return defaultValue;

            string ret = defaultValue;
            try
            {
                switch (key.GetValueKind(name))
                {
                    case RegistryValueKind.String:
                        ret = (string)key.GetValue(name, defaultValue);
                        break;
                    case RegistryValueKind.MultiString:
                        ret = "";
                        string[] data = new string[] { defaultValue };

                        data = (string[])key.GetValue(name, data);
                        if (data != null)
                        {
                            foreach (string s in data)
                            {
                                ret += s;
                                ret += ";";
                            }
                            if (ret.Length > 0)
                                ret = ret.Substring(0, ret.Length - 1);
                        }
                        break;
                    case RegistryValueKind.DWord:
                        ret = ((int)key.GetValue(name, int.Parse(defaultValue))).ToString();
                        break;
                }

                key.Close();
            }
            catch { }

            return ret;

        }
        public static int Read(string path, string name, int defaultValue)
        {
            int retVal = defaultValue;
            string sValue = defaultValue.ToString();
            string ret = Read(path, name, sValue);

            try
            {
                retVal = int.Parse(ret);
            }
            catch { }
            return retVal;

        }

        public static void Write(string path, string name, string data)
        {
            RegistryKey key = null;
            try
            {
                key = Registry.LocalMachine.OpenSubKey(path.Replace("/", "\\"), true);
            }
            catch { }

            if (key == null)
                key = buildPath(path, Registry.LocalMachine, true);

            key.SetValue(name, data, RegistryValueKind.String);
            key.Close();


        }
        public static void Write(string path, string name, int data)
        {
            RegistryKey key = null;
            try
            {
                key = Registry.LocalMachine.OpenSubKey(path.Replace("/", "\\"), true);
            }
            catch { }

            if (key == null)
                key = buildPath(path, Registry.LocalMachine, true);

            key.SetValue(name, data, RegistryValueKind.DWord);
            key.Close();
        }

        public static ArrayList EnumKeys(string path)
        {
            ArrayList ret = new ArrayList();
            RegistryKey key = Registry.LocalMachine.OpenSubKey(path.Replace("/", "\\"), true);
            if (key == null)
                return ret;


            foreach (string k in key.GetSubKeyNames())
                ret.Add(k);

            key.Close();
            return ret;

        }

        public static ArrayList EnumValues(string path)
        {
            ArrayList ret = new ArrayList();
            RegistryKey key = Registry.LocalMachine.OpenSubKey(path.Replace("/", "\\"), true);
            if (key == null)
                return ret;


            foreach (string k in key.GetValueNames())
                ret.Add(k);

            key.Close();
            return ret;

        }

        private static RegistryKey buildPath(string path, RegistryKey parent, bool writtable)
        {

            string[] temp = path.Split('/');
            foreach (string name in temp)
            {
                string existingKey = string.Empty;
                foreach (string subkey in parent.GetSubKeyNames())
                {
                    if (name.Equals(subkey, StringComparison.OrdinalIgnoreCase))
                    {
                        existingKey = subkey;
                        break;
                    }
                }
                RegistryKey currentKey = null;


                if (existingKey.Equals(string.Empty))
                {
                    if (!writtable)
                    {
                        parent.Close();
                        return null;
                    }

                    currentKey = parent.CreateSubKey(name);
                }
                else
                    currentKey = parent.OpenSubKey(existingKey, writtable);

                parent.Close();
                parent = currentKey;
            }
            return parent;
        }
    }
}
