﻿namespace SMS20
{
    partial class frmMain
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.mnuFile = new System.Windows.Forms.MenuItem();
            this.mnuLogin = new System.Windows.Forms.MenuItem();
            this.mnuConnect = new System.Windows.Forms.MenuItem();
            this.mnuPolling = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.mnuAuthorizeContact = new System.Windows.Forms.MenuItem();
            this.mnuDeleteContact = new System.Windows.Forms.MenuItem();
            this.mnuDisconnect = new System.Windows.Forms.MenuItem();
            this.mnuQuit = new System.Windows.Forms.MenuItem();
            this.txtPwd = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNick = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbStatus = new System.Windows.Forms.Label();
            this.lvContacts = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.label4 = new System.Windows.Forms.Label();
            this.wbMessages = new System.Windows.Forms.WebBrowser();
            this.mnuAddContact = new System.Windows.Forms.MenuItem();
            this.mnuSendMessage = new System.Windows.Forms.MenuItem();
            this.SuspendLayout();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.Add(this.mnuFile);
            this.mainMenu1.MenuItems.Add(this.mnuQuit);
            // 
            // mnuFile
            // 
            this.mnuFile.MenuItems.Add(this.mnuLogin);
            this.mnuFile.MenuItems.Add(this.mnuConnect);
            this.mnuFile.MenuItems.Add(this.mnuPolling);
            this.mnuFile.MenuItems.Add(this.menuItem2);
            this.mnuFile.MenuItems.Add(this.mnuDisconnect);
            this.mnuFile.Text = "File";
            // 
            // mnuLogin
            // 
            this.mnuLogin.Text = "Login";
            this.mnuLogin.Click += new System.EventHandler(this.mnuLogin_Click);
            // 
            // mnuConnect
            // 
            this.mnuConnect.Text = "Connect";
            this.mnuConnect.Click += new System.EventHandler(this.mnuConnect_Click);
            // 
            // mnuPolling
            // 
            this.mnuPolling.Text = "Pooling";
            this.mnuPolling.Click += new System.EventHandler(this.mnuPolling_Click);
            // 
            // menuItem2
            // 
            this.menuItem2.MenuItems.Add(this.mnuAddContact);
            this.menuItem2.MenuItems.Add(this.mnuAuthorizeContact);
            this.menuItem2.MenuItems.Add(this.mnuDeleteContact);
            this.menuItem2.MenuItems.Add(this.mnuSendMessage);
            this.menuItem2.Text = "Contacts";
            // 
            // mnuAuthorizeContact
            // 
            this.mnuAuthorizeContact.Text = "Authorize Contact";
            this.mnuAuthorizeContact.Click += new System.EventHandler(this.mnuAuthorizeContact_Click);
            // 
            // mnuDeleteContact
            // 
            this.mnuDeleteContact.Text = "Delete Contact";
            this.mnuDeleteContact.Click += new System.EventHandler(this.mnuDeleteContact_Click);
            // 
            // mnuDisconnect
            // 
            this.mnuDisconnect.Text = "Disconnect";
            this.mnuDisconnect.Click += new System.EventHandler(this.mnuDisconnect_Click);
            // 
            // mnuQuit
            // 
            this.mnuQuit.Text = "Quit";
            this.mnuQuit.Click += new System.EventHandler(this.mnuQuit_Click);
            // 
            // txtPwd
            // 
            this.txtPwd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPwd.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.txtPwd.Location = new System.Drawing.Point(65, 23);
            this.txtPwd.Name = "txtPwd";
            this.txtPwd.PasswordChar = '*';
            this.txtPwd.Size = new System.Drawing.Size(161, 19);
            this.txtPwd.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label2.Location = new System.Drawing.Point(3, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 16);
            this.label2.Text = "Password";
            // 
            // txtLogin
            // 
            this.txtLogin.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLogin.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.txtLogin.Location = new System.Drawing.Point(65, 3);
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(161, 19);
            this.txtLogin.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label1.Location = new System.Drawing.Point(4, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 16);
            this.label1.Text = "Login";
            // 
            // txtNick
            // 
            this.txtNick.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNick.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.txtNick.Location = new System.Drawing.Point(65, 45);
            this.txtNick.Name = "txtNick";
            this.txtNick.Size = new System.Drawing.Size(161, 19);
            this.txtNick.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label3.Location = new System.Drawing.Point(3, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.Text = "Nick";
            // 
            // lbStatus
            // 
            this.lbStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lbStatus.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.lbStatus.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbStatus.Location = new System.Drawing.Point(0, 254);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Size = new System.Drawing.Size(240, 14);
            this.lbStatus.Text = "[idle]";
            // 
            // lvContacts
            // 
            this.lvContacts.Columns.Add(this.columnHeader1);
            this.lvContacts.Columns.Add(this.columnHeader2);
            this.lvContacts.Columns.Add(this.columnHeader3);
            this.lvContacts.FullRowSelect = true;
            this.lvContacts.Location = new System.Drawing.Point(15, 86);
            this.lvContacts.Name = "lvContacts";
            this.lvContacts.Size = new System.Drawing.Size(211, 64);
            this.lvContacts.TabIndex = 27;
            this.lvContacts.View = System.Windows.Forms.View.Details;
            this.lvContacts.SelectedIndexChanged += new System.EventHandler(this.lvContacts_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Alias";
            this.columnHeader1.Width = 69;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Id";
            this.columnHeader2.Width = 63;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Status";
            this.columnHeader3.Width = 60;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label4.Location = new System.Drawing.Point(15, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 16);
            this.label4.Text = "Contacts";
            // 
            // wbMessages
            // 
            this.wbMessages.Location = new System.Drawing.Point(15, 156);
            this.wbMessages.Name = "wbMessages";
            this.wbMessages.Size = new System.Drawing.Size(210, 95);
            // 
            // mnuAddContact
            // 
            this.mnuAddContact.Text = "Add Contact";
            this.mnuAddContact.Click += new System.EventHandler(this.mnuAddContact_Click);
            // 
            // mnuSendMessage
            // 
            this.mnuSendMessage.Text = "Send Message";
            this.mnuSendMessage.Click += new System.EventHandler(this.mnuSendMessage_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.wbMessages);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lvContacts);
            this.Controls.Add(this.lbStatus);
            this.Controls.Add(this.txtNick);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPwd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtLogin);
            this.Controls.Add(this.label1);
            this.KeyPreview = true;
            this.Menu = this.mainMenu1;
            this.Name = "frmMain";
            this.Text = "Movistar SMS20";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuItem mnuFile;
        private System.Windows.Forms.MenuItem mnuQuit;
        private System.Windows.Forms.MenuItem mnuLogin;
        private System.Windows.Forms.TextBox txtPwd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNick;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbStatus;
        private System.Windows.Forms.MenuItem mnuConnect;
        private System.Windows.Forms.MenuItem mnuPolling;
        private System.Windows.Forms.ListView lvContacts;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.WebBrowser wbMessages;
        private System.Windows.Forms.MenuItem mnuAuthorizeContact;
        private System.Windows.Forms.MenuItem menuItem2;
        private System.Windows.Forms.MenuItem mnuDeleteContact;
        private System.Windows.Forms.MenuItem mnuDisconnect;
        private System.Windows.Forms.MenuItem mnuAddContact;
        private System.Windows.Forms.MenuItem mnuSendMessage;
    }
}

