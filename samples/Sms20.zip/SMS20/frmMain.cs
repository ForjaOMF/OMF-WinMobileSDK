using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SMS20
{
    public partial class frmMain : Form
    {
        private SMS20Api.SMS20 _sms20 = null;

        public frmMain()
        {
            InitializeComponent();

            txtLogin.Text = RegManager.Read("MovistarTest/Common", "login", "");
            txtPwd.Text = RegManager.Read("MovistarTest/Common", "pwd", "");
            txtNick.Text = RegManager.Read("MovistarTest/SMS20", "nick", "");

            mnuConnect.Enabled = false;
            mnuPolling.Enabled = false;
            mnuAddContact.Enabled = false;
            mnuAuthorizeContact.Enabled = false;
            mnuDeleteContact.Enabled = false;
            mnuSendMessage.Enabled = false;
            mnuDisconnect.Enabled = false;
            
        }

        private void SetControlEnabled(bool enabled)
        {
            if (enabled)
                Cursor.Current = Cursors.Default;
            else
                Cursor.Current = Cursors.WaitCursor;

            mnuLogin.Enabled = true;
            mnuFile.Enabled = enabled;
            mnuQuit.Enabled = enabled;
            txtLogin.Enabled = enabled;
            txtPwd.Enabled = enabled;
            txtNick.Enabled = enabled;
            lvContacts.Enabled = enabled;

            this.Refresh();

        }
        private void mnuQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void UpdateStatus(string data, bool isError)
        {
            lbStatus.Text = data;
            if (isError)
            {
                lbStatus.ForeColor = Color.Brown;
                MessageBox.Show(data, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            else
                lbStatus.ForeColor = Color.DarkGreen;
        }

        private void mnuLogin_Click(object sender, EventArgs e)
        {
            SetControlEnabled(false);
            _sms20 = new SMS20Api.SMS20();
            try
            {
                string sessionId = _sms20.Login(txtLogin.Text, txtPwd.Text);
                if (sessionId != null && sessionId.Length > 0)
                {
                    RegManager.Write("MovistarTest/Common", "login", txtLogin.Text);
                    RegManager.Write("MovistarTest/Common", "pwd", txtPwd.Text);
                    RegManager.Write("MovistarTest/SMS20", "nick", txtNick.Text);

                    mnuLogin.Enabled = false;
                    mnuConnect.Enabled = true;
                    mnuDisconnect.Enabled = true;

                    UpdateStatus("Login Success", false);
                }
                else
                    UpdateStatus("ERR: " + _sms20.GetLastError(), true);
            }
            catch (Exception ex)
            {
                UpdateStatus("Internal Error: " + ex.Message, true);
            }
            SetControlEnabled(true);

        }
        private void mnuConnect_Click(object sender, EventArgs e)
        {
            SetControlEnabled(false);
            try
            {
                ArrayList contacts = _sms20.Connect(txtLogin.Text, txtNick.Text);
                if (contacts != null)
                {

                    UpdateStatus("Connected to the Service", false);

                    mnuPolling.Enabled = true;
                    mnuAddContact.Enabled = true;

                    lvContacts.Items.Clear();
                    foreach (SMS20Api.Contact contact in contacts)
                        paintContact(contact);
                }
                else
                    UpdateStatus("ERR: " + _sms20.GetLastError(), true);
            }
            catch (Exception ex)
            {
                UpdateStatus("Internal Error: " + ex.Message, true);
            }
            SetControlEnabled(true);
        }
        private void mnuPolling_Click(object sender, EventArgs e)
        {
            SetControlEnabled(false);
            try
            {
                string retData = _sms20.Polling();
                if (retData != null)
                {
                    if (retData.Length == 0)
                        UpdateStatus("No pool data available", false);
                    else
                        parsePoolData(retData);
                }
                else
                    UpdateStatus("ERR: " + _sms20.GetLastError(), true);
            }
            catch (Exception ex)
            {
                UpdateStatus("Internal Error: " + ex.Message, true);
            }
            SetControlEnabled(true);
        }

        private void mnuAddContact_Click(object sender, EventArgs e)
        {
            
            string newContact = null;
            frmInput fInput = new frmInput("New contact Phone", "");
            fInput.ShowDialog();
            newContact = fInput.ReturnValue;
            fInput.Dispose();
            fInput = null;

            if (newContact != null)
            {
                SetControlEnabled(false);

                string nick = _sms20.AddContact(txtLogin.Text, newContact);
                if (nick != null && nick.Length > 0)
                    UpdateStatus("User Added (Nick: " + nick + ")", false);
                else
                    UpdateStatus("Unable to Add User: " + _sms20.GetLastError(), true);

                SetControlEnabled(true);
            }
            
        }
        private void mnuAuthorizeContact_Click(object sender, EventArgs e)
        {
            SetControlEnabled(false);
            
            if (lvContacts.SelectedIndices.Count == 0)
            {
                //cmdSMS20Auth.Enabled = false;
                return;
            }
            SMS20Api.Contact contact = (SMS20Api.Contact)lvContacts.Items[lvContacts.SelectedIndices[0]].Tag;
            if (_sms20.AuthorizeContact(contact.Id))
                UpdateStatus("User Authorized", false);
            else
                UpdateStatus("Unable to Authorize User: " + _sms20.GetLastError(), true);

            SetControlEnabled(true);
        }
        private void mnuDeleteContact_Click(object sender, EventArgs e)
        {
            SetControlEnabled(false);
            if (lvContacts.SelectedIndices.Count == 0)
            {
                //cmdSMS20Auth.Enabled = false;
                return;
            }
            SMS20Api.Contact contact = (SMS20Api.Contact)lvContacts.Items[lvContacts.SelectedIndices[0]].Tag;
            if (_sms20.DeleteContact(txtLogin.Text, contact.Phone))
                UpdateStatus("User Deleted", false);
            else
                UpdateStatus("Unable to Delete User: " + _sms20.GetLastError(), true);

            SetControlEnabled(true);
        }
        private void mnuSendMessage_Click(object sender, EventArgs e)
        {
            string body = null;
            frmInput fInput = new frmInput("Message Body", "");
            fInput.ShowDialog();
            body = fInput.ReturnValue;
            fInput.Dispose();
            fInput = null;

            
            if (body != null)
            {
                SetControlEnabled(false);

                SMS20Api.Contact contact = (SMS20Api.Contact)lvContacts.Items[lvContacts.SelectedIndices[0]].Tag;
                if (_sms20.SendMessage("wv:" + txtLogin.Text + "@movistar.es", contact.Id, body))
                    UpdateStatus("Msg Sent", false);
                else
                    UpdateStatus("Unable to send message: " + _sms20.GetLastError(), true);

                SetControlEnabled(true);
            }
            
        }

        private void mnuDisconnect_Click(object sender, EventArgs e)
        {
            SetControlEnabled(false);
            if (_sms20.Disconnect())
            {
                UpdateStatus("Disconnected Successfully", false);
                mnuLogin.Enabled = true;
                mnuConnect.Enabled = false;
                mnuPolling.Enabled = false;
                mnuAddContact.Enabled = false;
                mnuAuthorizeContact.Enabled = false;
                mnuDeleteContact.Enabled = false;
                mnuSendMessage.Enabled = false;
                mnuDisconnect.Enabled = false;
            }
            else
                UpdateStatus("Unable to Disconnect: " + _sms20.GetLastError(), true);

            SetControlEnabled(true);
        }

        private void parsePoolData(string data)
        {
            if (data.StartsWith("<PresenceNotification-Request "))
            {
                UpdateStatus("Presence Status Received", false);
                paintContact(_sms20.ParsePollPresenceNotification(data));
            }
            else if (data.StartsWith("<PresenceAuth-Request "))
            {
                UpdateStatus("Auth-Request Received", false);
                paintContact(_sms20.ParsePollPresenceAuthNotification(data));
            }
            else if (data.StartsWith("<NewMessage"))
            {
                UpdateStatus("Message Received", false);
                SMS20Api.InstantMessage msg = _sms20.ParsePollMessageNotification(data);
                StringBuilder sbHtml = new StringBuilder();
                sbHtml.Append("<span style=\"color:#336699;font-family:'Microsoft Sans Serif';font-style:normal;font-weight:bold;font-size:8px;\">" + msg.Received.ToLongTimeString() + " " + msg.Sender + " said: </span><br />");
                sbHtml.Append(msg.Body);
                wbMessages.DocumentText = sbHtml.ToString();
            }
        }
        private void paintContact(SMS20Api.Contact contact)
        {
            if (contact == null)
                return;

            // Update status if exists
            foreach (ListViewItem item in lvContacts.Items)
            {
                if (item.SubItems[1].Text == contact.Id)
                {
                    item.SubItems[2].Text = contact.Status.ToString();
                    item.Tag = contact;
                    return;
                }
            }
            // Create new
            ListViewItem newItem = new ListViewItem(contact.Alias);
            newItem.SubItems.Add(contact.Id);
            newItem.SubItems.Add(contact.Status.ToString());
            newItem.Tag = contact;
            lvContacts.Items.Add(newItem);
        }

        private void lvContacts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvContacts.SelectedIndices.Count == 0)
            {
                mnuAuthorizeContact.Enabled = false;
                mnuDeleteContact.Enabled = false;
                mnuSendMessage.Enabled = false;
                return;
            }
            SMS20Api.Contact contact = (SMS20Api.Contact)lvContacts.Items[lvContacts.SelectedIndices[0]].Tag;
            mnuAuthorizeContact.Enabled = (contact.Status == SMS20Api.Contact.ContactStatusEnum.authPending);
            mnuDeleteContact.Enabled = true;
            mnuSendMessage.Enabled = true;
        }
    }
}